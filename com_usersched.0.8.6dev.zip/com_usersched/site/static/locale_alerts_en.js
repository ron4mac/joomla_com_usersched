scheduler.__alerts = {
	locale: {
		alert_title: 'Alerts',
		alert_users: "Alert users",
		alert_method: "Alert method",
		alert_email: "Email",
		alert_SMS: "SMS",
		alert_both: "Both",
		alert_lead: "Alert lead",
		alert_minutes: "minute(s)",
		alert_hours: "hour(s)",
		alert_days: "day(s)",
		alert_weeks: "week(s)",
		alert_show: "Show",
		alert_hide: "Hide"
	}
};
