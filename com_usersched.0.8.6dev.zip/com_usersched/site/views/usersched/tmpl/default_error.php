<?php
defined('_JEXEC') or die;

if ($this->error)
	echo '<div class="error">'.$this->escape($this->error).'</div>';
?>