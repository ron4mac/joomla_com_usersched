<?php
//echo'<xmp>';var_dump($this->user->groups,$this->params->get('site_auth'));echo'</xmp>';
?>
THIS CALENDAR IS NOT ACCESSIBLE